#pragma once

#include "stdio.h"
#include "stdlib.h"
#include "malloc.h"
#include "string.h"
#include "cuda_runtime.h"
#include "math.h"
#include "time.h"
#include "device_launch_parameters.h"
#include "device_functions.h"
#include "cuda_device_runtime_api.h"
#include <curand.h>
#include <curand_kernel.h>

#define SQR(A) ((A)*(A))
#define M_PI 3.1415926536
#define BPSK(x) (1.0f-2.0f*(x))

#define SHIFT_CHAR(a, n) ((unsigned short)((a>>(n*16)) & 0x0000ffff))
#define SHIFT_UINT(a, n) (((uint)a & 0x0000ffff)<<(n*16))

//CL2017  

#define CodeA //32 X 64     
//#define CodeB //16 X 96   
//#define CodeC //62 X 186 
//#define CodeD //256 X 384 
//#define CodeE //192 X 384 
//#define CodeF //170 X 680


#define LOG_GF 8        // corresponding to the letter p in the paper
#define BLOCK_FRAME 1    // Ncb in the paper
#define ACTIVE_BLOCK 240   // Nb in the  paper

#define ITERATE_TIME 5    // k in the paper
#define STREAM_NUM 3      // Ns in the paper

//#define INTERLEAVE_TIME  // interleaving and deinterleaving time testing, NOTE THAT : only if STREAM_NUM == 1!!!!

#define TEST_MODE       // throughput/latency testing
//#define PLOT_MODE    // for achieving BER curves

#define TOTAL_DECODING_TEST   // including data transfer time
//#define KERNEL_TEST  // not includeing data transfer time

#ifdef CodeA
#define ROW_LENGTH 32
#define COL_LENGTH 64
#define ROW_DEG 4
#define COL_DEG 2
#endif

#ifdef CodeB
#define ROW_LENGTH 16
#define COL_LENGTH 96
#define ROW_DEG 12
#define COL_DEG 2
#endif

#ifdef CodeC
#define ROW_LENGTH 62
#define COL_LENGTH 186
#define ROW_DEG 6
#define COL_DEG 2
#endif

#ifdef CodeD
#define ROW_LENGTH 256
#define COL_LENGTH 384
#define ROW_DEG 3
#define COL_DEG 2
#endif

#ifdef CodeE
#define ROW_LENGTH 192
#define COL_LENGTH 384
#define ROW_DEG 4
#define COL_DEG 2
#endif

#ifdef CodeF
#define ROW_LENGTH 170
#define COL_LENGTH 680
#define ROW_DEG 8
#define COL_DEG 2
#endif

#define GF (1<<(LOG_GF))
#define ThreadpBlock ( GF/2 )
#define MSG_LENGTH (COL_LENGTH-ROW_LENGTH)
#define LAYER_NUM ROW_LENGTH
#define TOTAL_EDGE (ROW_LENGTH*ROW_DEG)

typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned short ushort;

typedef float mtype;

//check node message data structure definition
typedef mtype block_frame[(GF / 2 ) * BLOCK_FRAME];
typedef block_frame info_row_2_col[2];

typedef struct{
	info_row_2_col info[TOTAL_EDGE];
}INFO_ROW_2_COL;

typedef struct{
	info_row_2_col info[COL_LENGTH];
}INFO_CHANNEL;

typedef float RANDOM[COL_LENGTH*LOG_GF];
typedef int CODEWORD[COL_LENGTH];

typedef float tblock[GF];
typedef tblock TINFO_CHANNEL[COL_LENGTH];


__constant__ int d_FFTSQ_OPT[LOG_GF*GF];
__constant__ int d_MatValue[TOTAL_EDGE];
__constant__ int d_input_v[TOTAL_EDGE];
__constant__ int d_BINGF[GF*LOG_GF];




