#pragma once
#include "totalDefine.h"

#define PI 3.141592653


//#####################################################################################################
void construct_from_file(int *interleaver, char* FilePrefix){
	char FileName[500];
	FILE* f;
	int N, M;
	int *ColumnDegree, *RowDegree, **VatC, **CatV;
	int c = COL_DEG;
	int d = ROW_DEG;
	N = COL_LENGTH;
	M = N*c / d;
	ColumnDegree = (int *)calloc(N, sizeof(int));
	RowDegree = (int *)calloc(M, sizeof(int));
	for (int m = 0; m<M; m++) RowDegree[m] = d;
	for (int n = 0; n<N; n++) ColumnDegree[n] = c;

	VatC = (int **)calloc(M, sizeof(int *)); for (int m = 0; m<M; m++) VatC[m] = (int *)calloc(d, sizeof(int));
	CatV = (int **)calloc(N, sizeof(int *)); for (int n = 0; n<N; n++) CatV[n] = (int *)calloc(c, sizeof(int));

	strcpy(FileName, FilePrefix);

	f = fopen(FileName, "r");
	for (int m = 0; m<M; m++){ for (int i = 0; i<RowDegree[m]; i++){ fscanf(f, "%d", &VatC[m][i]); } }fclose(f);
	int ** NtoB = (int **)calloc(N, sizeof(int *)); for (int n = 0; n<N; n++) NtoB[n] = (int *)calloc(ColumnDegree[n], sizeof(int));
	int ind[COL_LENGTH]; for (int i = 0; i<N; i++)ind[i] = 0;
	int e = 0; for (int m = 0; m<M; m++) {
		for (int k = 0; k<RowDegree[m]; k++){
			int n = VatC[m][k];
			NtoB[n][ind[n]++] = e++;
		}
	}
	e = 0; for (int n = 0; n<N; n++) { for (int k = 0; k<ColumnDegree[n]; k++) interleaver[e++] = NtoB[n][k]; }
	
}

//#####################################################################################################
void InitEncoding(int *interleaver, int *MatValue, int M, int N, int *ADDGF, int *MULGF, int *DIVGF, int *G, int *HH){
	int H[ROW_LENGTH][COL_LENGTH];
	int K = N - M;
	int Perm[COL_LENGTH];
	for (int n = 0; n<N; n++){ Perm[n] = n; }
	for (int m = 0; m<M; m++)for (int n = 0; n<N; n++){H[m][n] = 0;HH[m*COL_LENGTH+n] = 0;}
	for (int n = 0; n<N; n++)for (int i = 0; i<COL_DEG; i++){ int e = interleaver[n*COL_DEG + i]; int m = e / ROW_DEG; H[m][n] = MatValue[e]; HH[m*COL_LENGTH + n] =  MatValue[e]; }

	int i, j, k, l, pivot;
	int p, q;

	for (i = 0; i<M; i++) {
		pivot = i;
		for (l = i; l<M; l++){
			if (H[l][i] != 0){
				pivot = l; break;
			}
		}
		if (pivot != i) {
			for (j = 0; j<N; j++) {
				int t = H[i][j];
				H[i][j] = H[pivot][j];
				H[pivot][j] = t;
			}
		}
	}

	for (k = 0; k<M; k++){
		p = H[k][k];
		if (p == 0){
			int j1, j2;
			for (j = k; j<N; j++){
				if (H[k][j] != 0){
					j1 = k;
					j2 = j;
					break;
				}
			}
			if (j == N){ printf("parity-check matrix is not full-rank!!\n"); exit(0); }
			p = H[k][j];
			printf("divided by zero H[%d][%d]=%3x=%3x\n", k, j, H[k][j], p);
			int t = Perm[j1]; Perm[j1] = Perm[j2]; Perm[j2] = t;
			for (i = 0; i<M; i++) {
				int t = H[i][j1];
				H[i][j1] = H[i][j2];
				H[i][j2] = t;
			}
		}
		for (j = 0; j<N; j++) {
			H[k][j] = DIVGF[H[k][j] * GF + p];
		}


		// ===== H[i] = H[i] + H[i][k]*H[k]  make upper triable matrix ===================
		for (i = k + 1; i<M; i++) {
			q = H[i][k];
			for (j = 0; j<N; j++) {
				int t = MULGF[q*GF + H[k][j]];
				H[i][j] = ADDGF[H[i][j] * GF + t];
			}
		}
	}
	// ===== H[i] = H[i] + H[i][k]*H[k]  make echelon matrix ============================
	for (k = 1; k<M; k++) {
		for (i = 0; i <= k - 1; i++){
			int g = H[i][k];
			for (j = 0; j<N; j++) {
				int t = MULGF[g*GF + H[k][j]];
				H[i][j] = ADDGF[H[i][j] * GF + t];
			}
		}
	}
	// ==== make G
	for (int m = 0; m<K; m++){ for (int n = 0; n<N; n++){ G[m*N + n] = 0; } }
	for (k = 0; k<K; k++){
		G[k*N + k + M] = 1;
		for (j = 0; j<N - K; j++) {
			G[k*N + j] = H[j][M + k];
		}
	}
	// ==== exchange j-th and k-th column ================================
	for (int i = 0; i<M; i++) {
		int T[COL_LENGTH];
		for (int j = 0; j<N; j++){ T[j] = H[i][j]; }
		for (int j1 = 0; j1<N; j1++){
			int j2 = Perm[j1];
			H[i][j2] = T[j1];
		}
	}
	for (int i = 0; i<N - M; i++) {
		int T[COL_LENGTH];
		for (int j = 0; j<N; j++){ T[j] = G[i*N + j]; }
		for (int j1 = 0; j1<N; j1++){
			int j2 = Perm[j1];
			G[i*N + j2] = T[j1];
		}
	}
}


//#####################################################################################################
void Encoding(int K, int N, int* G, int* Symbol, int *ADDGF, int *MULGF){
	int Info[MSG_LENGTH];	
	for (int k = 0; k<N; k++){ Symbol[k] = 0; } // all-zero
	for (int k = 0; k<K; k++){ Info[k] = rand() % GF; }
	for (int n = 0; n<N; n++)
	{
		Symbol[n] = 0;
		for (int k = 0; k<K; k++)
		{
			int s = Info[k];
			int g = G[k*N + n];
			int m = MULGF[s*GF + g];
			Symbol[n] = ADDGF[Symbol[n] * GF + m];
		}
	}
}
//#####################################################################################################
void print_syndrome(int *interleaver, int *MatValue, int M, int N, int *ADDGF, int *MULGF, int *G, int *Symbol){
	//printf("@print_syndrome\n");
	int H[ROW_LENGTH][COL_LENGTH];
	for (int m = 0; m<M; m++)for (int n = 0; n<N; n++)H[m][n] = 0;
	for (int n = 0; n<N; n++)for (int i = 0; i<COL_DEG; i++){ int e = interleaver[n*COL_DEG + i]; int m = e / ROW_DEG; H[m][n] = MatValue[e]; }
	int sum_synd = 0;
	//printf("syndrome=\n");
	for (int m = 0; m<M; m++){
		int sum = 0;
		for (int n = 0; n<N; n++){
			//printf("%x\n",Symbol[n]);
			int ax = MULGF[H[m][n] * GF + Symbol[n]];
			sum = ADDGF[ax*GF + sum];
		}
		
		sum_synd += sum;
		
	}
	printf("%3x ", sum_synd);
	//printf("\n");
}
//#####################################################################################################
__global__ void gpu_initialize_message(float *d_input, int *d_BINGF, int *d_Symbol, float *d_Rand1, float *d_Rand2, float d_ch){
	int n = blockIdx.y;
	int g = threadIdx.x;
	int d_Bit;
	__shared__ float p[LOG_GF][2];


	if (g<LOG_GF){
		// variable node
		float sigma = d_ch;
		float u = d_Rand1[n*LOG_GF + g];
		float v = d_Rand2[n*LOG_GF + g];
		d_Bit = d_BINGF[d_Symbol[n] * LOG_GF + g];
		float y = BPSK(d_Bit) + sigma*sqrtf(-2.0f * logf(u)) * __cosf(2 * M_PI * v);
		float llr = 2.0*y / SQR(sigma);
		float p0 = exp(llr) / (1.0f + exp(llr));
		p[g][0] = p0;
		p[g][1] = 1.0 - p0;
	}
	syncthreads();
	d_input[n*GF + g] = 1.0;
	for (int l = 0; l<LOG_GF; l++){
		if (d_BINGF[g*LOG_GF + l] == 0){
			d_input[n*GF + g] *= p[l][0];
		}
		else{
			d_input[n*GF + g] *= p[l][1];
		}
	}

}