#pragma once

#include "totalDefine.h"

#define PI 3.141592653


//void input_random(float Sigma_DB, float *input, int *BINGF)
//{
//	float *temp_p0;

//	float u, v, y, p0;
//	temp_p0 = (float *)malloc(sizeof(float)*COL_LENGTH*LOG_GF);
//	for (int i = 0; i < COL_LENGTH; i++)
//	{
//		for (int j = 0; j < LOG_GF; j++)
//		{
//			u = rand()*1.0f / RAND_MAX;
//			v = rand()*1.0f / RAND_MAX;
//			y = Sigma_DB*sqrtf(-2.0f * logf(u)) * cos(2 * M_PI * v) - 1;
//			y = 2.0*y / SQR(Sigma_DB);
//			p0 = exp(y) / (1.0f + exp(y));
//			temp_p0[i*LOG_GF + j] = p0;
//		}
//	}
//	for (int i = 0; i < COL_LENGTH; i++)
//	{
//		for (int j = 0; j < GF; j++)
//		{
//			for (int k = 0; k < LOG_GF; k++)
//			{
//				if (BINGF[j*LOG_GF + k] == 0)
//					input[i*GF + j] *= temp_p0[i*LOG_GF + k];
//				else
//					input[i*GF + j] *= (1 - temp_p0[i*LOG_GF + k]);
//			}
//		}
//	}
//	free(temp_p0);
//}


double Normal(double x,double miu,double sigma) //�����ܶȺ���
{
	return 1.0/sqrt(2*PI*sigma)*exp(-1*(x-miu)*(x-miu)/(2*sigma*sigma));
}
double AverageRandom(double min,double max)
{
	double temp;
	temp=rand();
	temp = temp/(double)RAND_MAX;//0~1
	temp=temp*(max-min)+min;//min~max
	//temp=2*max*temp;//-max~+max
	return temp;
}
double NormalRandom(double miu,double sigma,double min,double max)//������̬�ֲ������
{
	double x;
	double dScope;
	double y;
	double P;

	do
	{
		x = AverageRandom(min,max);//����min��max֮��������
		y = Normal(x, miu, sigma);//x�㴦�ĸ��ʴ�Сy
		P=Normal(miu,miu,sigma);
		dScope = AverageRandom(0,P);//x=0��ĸ��ʴ�СdScope
	}while( dScope > y);
	return x;
}


float Randn(int size,float *rand_N)
{
	int i;
	//char s[10];
	//string s;
	//rand_N = (float*)malloc(sizeof(float)*size);

	for(i=0;i<size;i++)
	{
		rand_N[i]=(float)NormalRandom(0,1,-6,+6);
	}
	//������������ļ���

	return 0;
}




